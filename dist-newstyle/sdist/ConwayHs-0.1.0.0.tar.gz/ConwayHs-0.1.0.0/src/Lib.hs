module Lib
    ( someFunc
    ) where

import Data.Map(Map)
import qualified Data.Map as M

newtype Dyadic = Dyadic Integer Integer

class Zero a where
    zero :: a

class One a where
    one :: a

class (Zero a, Ord a) => OrdZero a where
    neg :: a -> a

class OrdZero a => Add a where
    add :: a -> a -> a

class (OrdZero a, One a) => Mult a where
    mult :: a -> a -> a

class (Add a, Mult a) => Ring a where
    --

newtype Conway a = Conway (Map (Conway a, Conway a) a)
    deriving (Eq)

instance Zero (Conway a) where
    zero = Conway M.empty

instance One a => One (Conway a) where
    one = Conway (M.fromList [(zero, zero), one])

someFunc :: IO ()
someFunc = putStrLn "someFunc"
