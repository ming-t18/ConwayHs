# ConwayHs
